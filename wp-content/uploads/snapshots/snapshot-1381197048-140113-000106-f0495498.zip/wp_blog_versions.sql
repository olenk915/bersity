CREATE TABLE IF NOT EXISTS `wp_blog_versions` (
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `db_version` varchar(20) NOT NULL DEFAULT '',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`blog_id`),
  KEY `db_version` (`db_version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_blog_versions`;
 
INSERT INTO `wp_blog_versions` VALUES ('1', '26691', '2013-03-04 10:45:52'); 
INSERT INTO `wp_blog_versions` VALUES ('7', '26691', '2013-12-16 08:13:41'); 
INSERT INTO `wp_blog_versions` VALUES ('6', '26691', '2013-12-16 08:13:42'); 
INSERT INTO `wp_blog_versions` VALUES ('5', '26691', '2013-12-16 08:13:45'); 
INSERT INTO `wp_blog_versions` VALUES ('3', '26691', '2013-12-16 08:13:47');
# --------------------------------------------------------

