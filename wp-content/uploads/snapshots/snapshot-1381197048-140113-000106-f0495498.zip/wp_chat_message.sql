CREATE TABLE IF NOT EXISTS `wp_chat_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` varchar(255) NOT NULL,
  `avatar` varchar(1024) NOT NULL,
  `message` text NOT NULL,
  `moderator` enum('yes','no') NOT NULL DEFAULT 'no',
  `archived` enum('yes','no','yes-deleted','no-deleted') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`),
  KEY `chat_id` (`chat_id`),
  KEY `timestamp` (`timestamp`),
  KEY `archived` (`archived`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_chat_message`;
 
INSERT INTO `wp_chat_message` VALUES ('1', '1', '1', '2013-12-16 22:36:09', 'BVersity', 'iris@entmarketing.com', 'hello', 'yes', 'no');
# --------------------------------------------------------

