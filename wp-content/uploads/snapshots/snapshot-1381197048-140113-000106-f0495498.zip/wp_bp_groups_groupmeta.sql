CREATE TABLE IF NOT EXISTS `wp_bp_groups_groupmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=300 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bp_groups_groupmeta`;
 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('247', '94', '_bbp_forum_enabled_179', '1'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('248', '95', 'last_activity', '2013-07-09 16:01:47'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('251', '95', 'forum_id', 'a:1:{i:0;i:180;}'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('249', '95', 'total_member_count', '1'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('250', '95', 'invite_status', 'members'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('246', '94', 'forum_id', 'a:1:{i:0;i:179;}'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('245', '94', 'invite_status', 'members'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('243', '94', 'last_activity', '2013-07-08 17:13:33'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('244', '94', 'total_member_count', '1'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('299', '107', '_bbp_forum_enabled_225', '1'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('298', '107', 'forum_id', 'a:1:{i:0;i:225;}'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('291', '105', '_bbp_forum_enabled_223', '1'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('292', '106', 'invite_status', 'members'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('293', '107', 'last_activity', '2013-10-07 02:19:24'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('294', '107', 'total_member_count', '4'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('295', '106', 'forum_id', 'a:1:{i:0;i:224;}'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('296', '106', '_bbp_forum_enabled_224', '1'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('297', '107', 'invite_status', 'members'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('290', '105', 'forum_id', 'a:1:{i:0;i:223;}'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('289', '105', 'invite_status', 'members'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('288', '106', 'total_member_count', '5'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('252', '95', '_bbp_forum_enabled_180', '1'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('253', '96', 'last_activity', '2013-07-09 18:51:28'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('254', '96', 'total_member_count', '3'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('255', '96', 'invite_status', 'mods'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('256', '96', 'forum_id', 'a:1:{i:0;i:181;}'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('257', '96', '_bbp_forum_enabled_181', '1'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('258', '97', 'last_activity', '2013-10-07 21:06:43'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('259', '97', 'total_member_count', '1'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('260', '97', 'invite_status', 'members'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('261', '97', 'forum_id', 'a:1:{i:0;i:253;}'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('262', '97', '_bbp_forum_enabled_193', '1'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('275', '102', 'last_activity', '2013-10-08 14:26:28'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('276', '102', 'total_member_count', '5'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('277', '102', 'invite_status', 'members'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('278', '102', 'forum_id', 'a:1:{i:0;i:221;}'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('279', '102', '_bbp_forum_enabled_221', '1'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('280', '103', 'last_activity', '2013-10-07 02:19:39'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('281', '103', 'total_member_count', '5'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('282', '104', 'last_activity', '2013-10-07 04:28:57'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('283', '104', 'total_member_count', '6'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('284', '104', 'invite_status', 'members'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('285', '105', 'last_activity', '2013-10-07 02:45:26'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('286', '105', 'total_member_count', '5'); 
INSERT INTO `wp_bp_groups_groupmeta` VALUES ('287', '106', 'last_activity', '2013-10-07 02:45:42');
# --------------------------------------------------------

