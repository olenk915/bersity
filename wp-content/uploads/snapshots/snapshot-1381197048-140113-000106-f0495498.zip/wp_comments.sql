CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_comments`;
 
INSERT INTO `wp_comments` VALUES ('73', '2', 'LutherDow', 'yourmail@gmail.com', 'http://fermandia.biz/?i=356', '128.69.185.136', '2014-01-06 17:08:35', '2014-01-06 17:08:35', 'Для того что бы начать играть и зарабатывать, вам нужно зарегистрироваться в игре и купить животных для своей фермы. \r\nНа выбор 5 животных: курица, свинья, коза, овца и корова. На вашей ферме может быть любое количество животных. \r\nКаждое животное дает определенную продукцию, которую можно продать на рынке и получить за неё золотые монеты. \r\nЗолотые монеты можно вывести на ваш реальный счет PAYEER... \r\n \r\nПреимущества нашей игры: \r\n \r\n- Пополнение и выплаты на все популярные платежные системы; \r\n- Автоматическое накопление и выкуп продукции системой; \r\n- Никаких ограничений на срок жизни ваших животных, купленные животные остаются у вас навсегда; \r\n- Прозрачность статистики резерва, гарантирует вам постоянные выплаты; \r\n- Доброжелательная техническая поддержка 16 часов в день, 7 дней в неделю. \r\n \r\nРегистрация: http://fermandia.biz/?i=356', '0', '0', 'Opera/9.80 (Windows NT 6.1; Win64; x64; Edition Yx) Presto/2.12.388 Version/12.11', '', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('74', '2', 'sabinakryglova', 'khvolsonkhvolstr@gmail.com', 'http://transportdays.kz', '134.249.53.133', '2014-01-06 20:46:03', '2014-01-06 20:46:03', '<a href="http://teplomarket.kz" rel="nofollow">Интернет-магазин ковров</a>', '0', '0', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.5 (KHTML, like Gecko) YaBrowser/1.1.1084.5409 Chrome/19.1.1084.5409 Safari/536.5', '', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('75', '2', 'sabinakryglova', 'khvolsonkhvolstr@gmail.com', 'http://myxango.kz', '134.249.53.133', '2014-01-07 12:00:25', '2014-01-07 12:00:25', '<a href="http://obrezanie.kz" rel="nofollow"> почему делают обрезание  </a>', '0', '0', 'Opera/9.80 (Windows NT 6.1) Presto/2.12.388 Version/12.10', '', '0', '0');
# --------------------------------------------------------

