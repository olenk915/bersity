CREATE TABLE IF NOT EXISTS `wp_bp_user_blogs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `blog_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `blog_id` (`blog_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bp_user_blogs`;
 
INSERT INTO `wp_bp_user_blogs` VALUES ('1', '2', '1'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('2', '1', '1'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('3', '3', '1'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('5', '1', '3'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('11', '220', '1'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('12', '219', '6'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('9', '1', '5'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('10', '219', '5'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('13', '224', '6'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('14', '220', '7'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('15', '224', '7'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('16', '230', '1'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('17', '245', '1'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('18', '244', '1'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('19', '228', '1'); 
INSERT INTO `wp_bp_user_blogs` VALUES ('20', '247', '1');
# --------------------------------------------------------

