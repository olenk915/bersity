CREATE TABLE IF NOT EXISTS `wp_registration_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL DEFAULT '',
  `IP` varchar(30) NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=MyISAM AUTO_INCREMENT=220 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_registration_log`;
 
INSERT INTO `wp_registration_log` VALUES ('1', 'iris@entmarketing.com', '189.74.163.183', '2', '2013-03-04 18:01:39'); 
INSERT INTO `wp_registration_log` VALUES ('2', 'iris@entmarketing.com', '189.74.163.183', '3', '2013-03-04 18:08:11'); 
INSERT INTO `wp_registration_log` VALUES ('213', 'salehul@anblik.com', '115.187.35.31', '1', '2013-06-06 12:47:36'); 
INSERT INTO `wp_registration_log` VALUES ('214', 'salehul.h@gmail.com', '115.187.35.31', '1', '2013-06-06 13:01:06'); 
INSERT INTO `wp_registration_log` VALUES ('215', 'salehul.h@gmail.com', '115.187.35.31', '1', '2013-06-06 13:14:54'); 
INSERT INTO `wp_registration_log` VALUES ('216', 'salehul@anblik.com', '115.187.35.135', '4', '2013-06-11 02:40:07'); 
INSERT INTO `wp_registration_log` VALUES ('217', 'iris@entmarketing.com', '203.171.245.124', '5', '2013-06-23 20:43:16'); 
INSERT INTO `wp_registration_log` VALUES ('218', 'salehul.h@gmail.com', '115.187.36.143', '6', '2013-07-01 18:46:07'); 
INSERT INTO `wp_registration_log` VALUES ('219', 'mohri@stjohns.edu', '115.187.36.143', '7', '2013-07-01 18:53:04');
# --------------------------------------------------------

