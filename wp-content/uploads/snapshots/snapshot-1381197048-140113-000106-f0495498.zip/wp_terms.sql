CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_terms`;
 
INSERT INTO `wp_terms` VALUES ('1', 'Uncategorized', 'uncategorized', '0'); 
INSERT INTO `wp_terms` VALUES ('2', 'Blogroll', 'blogroll', '0'); 
INSERT INTO `wp_terms` VALUES ('18', 'Blogging', 'blogging', '0'); 
INSERT INTO `wp_terms` VALUES ('19', 'Featured Artists', 'featured-artists', '0'); 
INSERT INTO `wp_terms` VALUES ('20', 'new', 'new', '0'); 
INSERT INTO `wp_terms` VALUES ('21', 'How', 'how', '0'); 
INSERT INTO `wp_terms` VALUES ('22', 'To', 'to', '0'); 
INSERT INTO `wp_terms` VALUES ('23', 'Tag', 'tag', '0'); 
INSERT INTO `wp_terms` VALUES ('24', '&quot;Right&quot;', 'right', '0'); 
INSERT INTO `wp_terms` VALUES ('25', 'topic', 'topic', '0'); 
INSERT INTO `wp_terms` VALUES ('26', 'asf', 'asf', '0'); 
INSERT INTO `wp_terms` VALUES ('27', 'zxvczxv', 'zxvczxv', '0'); 
INSERT INTO `wp_terms` VALUES ('28', 'fasdf', 'fasdf', '0'); 
INSERT INTO `wp_terms` VALUES ('29', 'fasd', 'fasd', '0'); 
INSERT INTO `wp_terms` VALUES ('30', 'sdfgsd', 'sdfgsd', '0'); 
INSERT INTO `wp_terms` VALUES ('31', 'asdf', 'asdf', '0'); 
INSERT INTO `wp_terms` VALUES ('32', 'sadf', 'sadf', '0'); 
INSERT INTO `wp_terms` VALUES ('33', 'asdfa', 'asdfa', '0'); 
INSERT INTO `wp_terms` VALUES ('34', 'gdfsg', 'gdfsg', '0'); 
INSERT INTO `wp_terms` VALUES ('35', 'ttt', 'ttt', '0'); 
INSERT INTO `wp_terms` VALUES ('36', 'zxcv', 'zxcv', '0'); 
INSERT INTO `wp_terms` VALUES ('37', 'vxc', 'vxc', '0'); 
INSERT INTO `wp_terms` VALUES ('38', 'asd', 'asd', '0'); 
INSERT INTO `wp_terms` VALUES ('39', 'ewrt', 'ewrt', '0'); 
INSERT INTO `wp_terms` VALUES ('40', 'testing', 'testing', '0'); 
INSERT INTO `wp_terms` VALUES ('41', 'network', 'network', '0'); 
INSERT INTO `wp_terms` VALUES ('42', 'test', 'test', '0'); 
INSERT INTO `wp_terms` VALUES ('43', 'Health', 'health', '0'); 
INSERT INTO `wp_terms` VALUES ('44', 'Events', 'events', '0'); 
INSERT INTO `wp_terms` VALUES ('45', 'uLife', 'ulife', '0'); 
INSERT INTO `wp_terms` VALUES ('46', 'Jobs', 'jobs', '0'); 
INSERT INTO `wp_terms` VALUES ('47', 'Travel', 'travel', '0'); 
INSERT INTO `wp_terms` VALUES ('48', 'Food', 'food', '0'); 
INSERT INTO `wp_terms` VALUES ('49', 'Sports', 'sports', '0'); 
INSERT INTO `wp_terms` VALUES ('50', 'Fashion', 'fashion', '0'); 
INSERT INTO `wp_terms` VALUES ('51', 'uNews', 'unews', '0'); 
INSERT INTO `wp_terms` VALUES ('52', 'Opinion', 'opinion', '0'); 
INSERT INTO `wp_terms` VALUES ('55', 'America', 'america', '0'); 
INSERT INTO `wp_terms` VALUES ('54', 'Europe', 'europe', '0'); 
INSERT INTO `wp_terms` VALUES ('56', 'Canada', 'canada', '0'); 
INSERT INTO `wp_terms` VALUES ('57', 'USA', 'usa', '0'); 
INSERT INTO `wp_terms` VALUES ('58', 'Mexico', 'mexico', '0'); 
INSERT INTO `wp_terms` VALUES ('59', 'France', 'france', '0'); 
INSERT INTO `wp_terms` VALUES ('60', 'Italy', 'italy', '0'); 
INSERT INTO `wp_terms` VALUES ('61', 'Campus', 'campus', '0'); 
INSERT INTO `wp_terms` VALUES ('75', 'Movies', 'movies', '0'); 
INSERT INTO `wp_terms` VALUES ('63', 'Entertainment', 'entertainment', '0'); 
INSERT INTO `wp_terms` VALUES ('64', 'beyonce', 'beyonce', '0'); 
INSERT INTO `wp_terms` VALUES ('65', 'drunk in love', 'drunk-in-love', '0'); 
INSERT INTO `wp_terms` VALUES ('66', 'anchorman', 'anchorman', '0'); 
INSERT INTO `wp_terms` VALUES ('67', 'Sam Smith', 'sam-smith', '0'); 
INSERT INTO `wp_terms` VALUES ('68', 'Capitol Records', 'capitol-records', '0'); 
INSERT INTO `wp_terms` VALUES ('69', 'Lay Me Down', 'lay-me-down', '0'); 
INSERT INTO `wp_terms` VALUES ('70', 'La La La', 'la-la-la', '0'); 
INSERT INTO `wp_terms` VALUES ('71', 'Soul', 'soul', '0'); 
INSERT INTO `wp_terms` VALUES ('72', 'Pop', 'pop', '0'); 
INSERT INTO `wp_terms` VALUES ('73', 'Latch', 'latch', '0'); 
INSERT INTO `wp_terms` VALUES ('74', 'Money On My Mind', 'money-on-my-mind', '0'); 
INSERT INTO `wp_terms` VALUES ('76', 'Music', 'music', '0'); 
INSERT INTO `wp_terms` VALUES ('77', 'Brazilian Jiu-Jitsu', 'brazilian-jiu-jitsu', '0'); 
INSERT INTO `wp_terms` VALUES ('78', 'sports', 'sports-2', '0'); 
INSERT INTO `wp_terms` VALUES ('79', 'paramore', 'paramore', '0'); 
INSERT INTO `wp_terms` VALUES ('80', 'black sun', 'black-sun', '0'); 
INSERT INTO `wp_terms` VALUES ('81', 'music', 'music-2', '0'); 
INSERT INTO `wp_terms` VALUES ('82', 'albums', 'albums', '0'); 
INSERT INTO `wp_terms` VALUES ('83', '2013', '2013', '0'); 
INSERT INTO `wp_terms` VALUES ('84', 'hummingbird', 'hummingbird', '0'); 
INSERT INTO `wp_terms` VALUES ('85', 'night time', 'night-time', '0'); 
INSERT INTO `wp_terms` VALUES ('86', 'evil friends', 'evil-friends', '0'); 
INSERT INTO `wp_terms` VALUES ('87', 'hip hop', 'hip-hop', '0');
# --------------------------------------------------------

