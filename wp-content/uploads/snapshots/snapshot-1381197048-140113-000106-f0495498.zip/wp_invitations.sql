CREATE TABLE IF NOT EXISTS `wp_invitations` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(9) DEFAULT NULL,
  `invited_email` varchar(255) DEFAULT NULL,
  `datestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_invitations`;

# --------------------------------------------------------

