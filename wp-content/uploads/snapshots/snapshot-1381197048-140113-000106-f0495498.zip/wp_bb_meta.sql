CREATE TABLE IF NOT EXISTS `wp_bb_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `object_type` varchar(16) NOT NULL DEFAULT 'bb_option',
  `object_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `object_type__meta_key` (`object_type`,`meta_key`),
  KEY `object_type__object_id__meta_key` (`object_type`,`object_id`,`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bb_meta`;

# --------------------------------------------------------

