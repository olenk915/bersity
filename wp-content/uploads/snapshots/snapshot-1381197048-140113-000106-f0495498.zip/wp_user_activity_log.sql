CREATE TABLE IF NOT EXISTS `wp_user_activity_log` (
  `log_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_ID` bigint(35) NOT NULL DEFAULT '0',
  `visit_date` bigint(35) NOT NULL DEFAULT '0',
  PRIMARY KEY (`log_ID`),
  KEY `visit_date` (`visit_date`),
  KEY `user_id` (`user_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_user_activity_log`;
 
INSERT INTO `wp_user_activity_log` VALUES ('1', '1', '1376620703'); 
INSERT INTO `wp_user_activity_log` VALUES ('2', '0', '1376621762'); 
INSERT INTO `wp_user_activity_log` VALUES ('3', '1', '1376622644'); 
INSERT INTO `wp_user_activity_log` VALUES ('4', '0', '1376625165'); 
INSERT INTO `wp_user_activity_log` VALUES ('5', '0', '1376630881'); 
INSERT INTO `wp_user_activity_log` VALUES ('6', '0', '1376632689'); 
INSERT INTO `wp_user_activity_log` VALUES ('7', '0', '1376636137'); 
INSERT INTO `wp_user_activity_log` VALUES ('8', '0', '1376640811'); 
INSERT INTO `wp_user_activity_log` VALUES ('9', '0', '1376648194'); 
INSERT INTO `wp_user_activity_log` VALUES ('10', '0', '1376650211'); 
INSERT INTO `wp_user_activity_log` VALUES ('11', '0', '1376654065'); 
INSERT INTO `wp_user_activity_log` VALUES ('12', '0', '1376660268'); 
INSERT INTO `wp_user_activity_log` VALUES ('13', '0', '1376663768'); 
INSERT INTO `wp_user_activity_log` VALUES ('14', '0', '1376669219'); 
INSERT INTO `wp_user_activity_log` VALUES ('15', '0', '1376671440'); 
INSERT INTO `wp_user_activity_log` VALUES ('16', '0', '1376676542'); 
INSERT INTO `wp_user_activity_log` VALUES ('17', '0', '1376680761'); 
INSERT INTO `wp_user_activity_log` VALUES ('18', '0', '1376693960'); 
INSERT INTO `wp_user_activity_log` VALUES ('19', '0', '1376696093'); 
INSERT INTO `wp_user_activity_log` VALUES ('20', '0', '1376697904'); 
INSERT INTO `wp_user_activity_log` VALUES ('21', '1', '1376700318'); 
INSERT INTO `wp_user_activity_log` VALUES ('22', '1', '1376703055'); 
INSERT INTO `wp_user_activity_log` VALUES ('23', '1', '1376704857'); 
INSERT INTO `wp_user_activity_log` VALUES ('24', '0', '1376706897'); 
INSERT INTO `wp_user_activity_log` VALUES ('25', '0', '1376715017'); 
INSERT INTO `wp_user_activity_log` VALUES ('26', '0', '1376718021'); 
INSERT INTO `wp_user_activity_log` VALUES ('27', '0', '1376723665'); 
INSERT INTO `wp_user_activity_log` VALUES ('28', '0', '1376726377'); 
INSERT INTO `wp_user_activity_log` VALUES ('29', '0', '1376728391'); 
INSERT INTO `wp_user_activity_log` VALUES ('30', '0', '1376732123'); 
INSERT INTO `wp_user_activity_log` VALUES ('31', '0', '1376735323'); 
INSERT INTO `wp_user_activity_log` VALUES ('32', '0', '1376738823'); 
INSERT INTO `wp_user_activity_log` VALUES ('33', '0', '1376741281'); 
INSERT INTO `wp_user_activity_log` VALUES ('34', '0', '1376745824'); 
INSERT INTO `wp_user_activity_log` VALUES ('35', '0', '1376749093'); 
INSERT INTO `wp_user_activity_log` VALUES ('36', '0', '1376755792'); 
INSERT INTO `wp_user_activity_log` VALUES ('37', '1', '1376759088'); 
INSERT INTO `wp_user_activity_log` VALUES ('38', '0', '1376759411');
# --------------------------------------------------------

