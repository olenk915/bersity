CREATE TABLE IF NOT EXISTS `wp_myboard_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(7) NOT NULL,
  `albumNumber` int(2) NOT NULL,
  `imagepath` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_myboard_images`;
 
INSERT INTO `wp_myboard_images` VALUES ('29', '1', '4', 'Blue hills (20).jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('28', '1', '3', 'wallpaper1 (2).jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('19', '225', '5', 'IMG_0015.JPG,'); 
INSERT INTO `wp_myboard_images` VALUES ('20', '225', '4', 'IMG_0018.JPG,'); 
INSERT INTO `wp_myboard_images` VALUES ('21', '223', '0', 'image.jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('22', '223', '4', 'image (1).jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('23', '227', '0', 'image (2).jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('24', '227', '5', 'IMG_0057.JPG,'); 
INSERT INTO `wp_myboard_images` VALUES ('25', '227', '3', 'image (3).jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('26', '1', '0', 'Blue hills (19).jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('38', '228', '0', 'Screen shot 2012-12-28 at 11.03.30 AM.png,'); 
INSERT INTO `wp_myboard_images` VALUES ('27', '1', '7', 'Blue hills (18).jpg,Water lilies (40).jpg,Winter (33).jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('18', '225', '0', '277534395756320151_fN6jaDi6_c.jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('17', '220', '3', 'Iphone Import 779.JPG,'); 
INSERT INTO `wp_myboard_images` VALUES ('30', '1', '8', 'wallpaper1 (1).jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('31', '222', '0', '2013-03-09_00-48-18_206.jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('32', '222', '1', 'IMG_20130509_233446_520.jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('33', '222', '4', '2013-01-12_12-02-37_843 2.jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('34', '222', '3', '2012-09-30_03-14-20_119.jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('35', '222', '7', 'image (4).jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('36', '222', '9', ''); 
INSERT INTO `wp_myboard_images` VALUES ('37', '1', '1', 'Winter (34).jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('39', '228', '4', 'Photo on 2012-09-15 at 22.32.jpg,'); 
INSERT INTO `wp_myboard_images` VALUES ('40', '228', '3', 'Screen shot 2012-06-08 at 10.12.51 PM.png,'); 
INSERT INTO `wp_myboard_images` VALUES ('41', '228', '5', 'Screen shot 2012-12-29 at 11.19.33 AM.png,');
# --------------------------------------------------------

