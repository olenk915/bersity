CREATE TABLE IF NOT EXISTS `wp_bp_activity_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `activity_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `activity_id` (`activity_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bp_activity_meta`;
 
INSERT INTO `wp_bp_activity_meta` VALUES ('21', '704', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('23', '655', 'favorite_count', '3'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('24', '747', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('25', '762', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('22', '656', 'favorite_count', '2'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('14', '522', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('5', '495', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('13', '509', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('11', '507', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('12', '508', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('16', '655', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('17', '662', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('18', '663', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('19', '664', 'bpfb_blog_id', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('20', '664', 'favorite_count', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('26', '762', 'favorite_count', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('27', '890', 'favorite_count', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('28', '894', 'favorite_count', '1'); 
INSERT INTO `wp_bp_activity_meta` VALUES ('29', '953', 'favorite_count', '1');
# --------------------------------------------------------

