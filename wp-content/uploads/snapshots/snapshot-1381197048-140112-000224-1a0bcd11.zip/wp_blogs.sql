CREATE TABLE IF NOT EXISTS `wp_blogs` (
  `blog_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `domain` varchar(200) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `public` tinyint(2) NOT NULL DEFAULT '1',
  `archived` tinyint(2) NOT NULL DEFAULT '0',
  `mature` tinyint(2) NOT NULL DEFAULT '0',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  `lang_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_blogs`;
 
INSERT INTO `wp_blogs` VALUES ('1', '1', 'bandversity.com', '/', '2013-03-04 17:42:37', '2014-01-06 21:45:55', '1', '0', '0', '0', '0', '0'); 
INSERT INTO `wp_blogs` VALUES ('3', '1', 'bandversity.com', '/syracuse/', '2013-03-04 18:08:11', '2013-03-04 18:10:23', '1', '0', '0', '0', '0', '0'); 
INSERT INTO `wp_blogs` VALUES ('5', '1', 'bandversity.com', '/schoola2z/', '2013-06-23 20:43:15', '2013-06-23 20:43:17', '0', '0', '0', '0', '0', '0'); 
INSERT INTO `wp_blogs` VALUES ('6', '1', 'bandversity.com', '/sandysite/', '2013-07-01 18:46:07', '2013-07-01 18:46:07', '0', '0', '0', '0', '0', '0'); 
INSERT INTO `wp_blogs` VALUES ('7', '1', 'bandversity.com', '/irisdblog/', '2013-07-01 18:53:02', '2013-07-01 18:53:04', '0', '0', '0', '0', '0', '0');
# --------------------------------------------------------

