CREATE TABLE IF NOT EXISTS `wp_bp_xprofile_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `value` longtext NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=253 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bp_xprofile_data`;
 
INSERT INTO `wp_bp_xprofile_data` VALUES ('1', '1', '1', 'BVersity', '2013-06-25 00:37:42'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('2', '1', '1', 'BVersity', '2013-06-25 00:37:42'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('3', '1', '1', 'BVersity', '2013-06-25 00:37:42'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('4', '1', '1', 'BVersity', '2013-06-25 00:37:42'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('5', '1', '2', 'bruno', '2013-11-05 19:53:04'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('7', '1', '4', 'BakerMalcolm', '2013-03-07 02:33:11'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('228', '1', '224', 'sandy111', '2013-07-01 18:46:06'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('229', '1', '225', 'Rebecca Hart', '2013-07-05 18:59:48'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('230', '1', '226', 'Christy Ambrosini', '2013-07-09 15:45:17'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('231', '1', '227', 'Neysa Smith', '2013-07-09 18:30:23'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('232', '1', '228', 'Dana Glatzer', '2013-12-23 23:17:28'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('233', '1', '229', 'Erica Jackson', '2013-09-22 23:12:58'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('234', '1', '230', 'orentaub', '2013-10-01 19:12:51'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('235', '1', '231', 'Maddie Genco', '2013-10-07 02:46:52'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('236', '1', '232', 'Kristofer Regan', '2013-10-07 02:00:51'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('237', '1', '233', 'Hunter Hamilton', '2013-10-07 02:00:55'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('238', '1', '234', 'Roberto Modesto', '2013-10-07 02:01:52'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('239', '1', '235', 'Tyler Rosenberg', '2013-10-07 02:02:01'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('240', '1', '236', 'Josh Jackson', '2013-10-09 15:59:30'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('241', '1', '237', 'michael vassallo', '2013-10-09 21:08:17'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('242', '1', '238', 'Ariella Suchow', '2013-10-09 22:42:44'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('243', '1', '239', 'Jordan Suchow', '2013-10-09 22:52:57'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('244', '1', '240', 'Dylan Rocke', '2013-10-10 04:48:28'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('245', '1', '241', 'Sebastian Zar', '2013-10-15 14:29:16'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('246', '1', '242', 'Jade Pilgrom', '2013-10-22 02:55:33'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('247', '1', '243', 'sports', '2013-12-04 18:28:54'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('248', '1', '244', 'Kimberley Valderas', '2013-12-18 03:19:50'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('249', '1', '245', 'Kevin Montes', '2013-12-16 22:14:02'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('250', '1', '246', 'Heather Hilsenrod', '2013-12-24 00:06:47'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('251', '1', '247', 'Jacob Prussman', '2013-12-24 22:21:24'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('252', '1', '248', 'Rachel Dely', '2014-01-09 05:16:59'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('166', '1', '163', 'Connor Gagnon', '2013-05-19 17:44:09'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('172', '1', '169', 'Richie Reed', '2013-05-20 06:39:43'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('190', '1', '187', 'samelonkiRA', '2013-05-24 13:31:09'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('191', '1', '188', 'beagmamoimaSV', '2013-05-24 18:18:00'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('200', '1', '197', 'Lorenzo Clanton', '2013-06-03 18:09:11'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('201', '1', '198', 'Aidan Rigby', '2013-06-04 09:15:54'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('203', '1', '200', 'Lucas Randall', '2013-06-04 15:47:38'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('207', '1', '204', 'Agnes Dozier', '2013-06-05 00:30:06'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('213', '1', '210', 'Ute Camacho', '2013-06-06 01:53:05'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('214', '1', '211', 'Mohamed Ahern', '2013-06-06 06:06:54'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('221', '2', '1', '8013452325', '2013-06-11 02:05:19'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('222', '1', '218', 'what is this', '2013-06-19 14:17:18'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('223', '1', '219', 'Sandy Developer', '2013-07-05 22:25:17'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('224', '1', '220', 'Risi Mohr', '2013-09-03 03:45:54'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('226', '1', '222', 'Jonathan Viano', '2013-06-27 23:39:22'); 
INSERT INTO `wp_bp_xprofile_data` VALUES ('227', '1', '223', 'Arejay Silver', '2013-06-28 14:34:51');
# --------------------------------------------------------

