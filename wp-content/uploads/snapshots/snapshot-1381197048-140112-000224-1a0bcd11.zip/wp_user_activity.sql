CREATE TABLE IF NOT EXISTS `wp_user_activity` (
  `active_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_ID` bigint(35) NOT NULL DEFAULT '0',
  `last_active` bigint(35) NOT NULL DEFAULT '0',
  PRIMARY KEY (`active_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_user_activity`;
 
INSERT INTO `wp_user_activity` VALUES ('1', '1', '1376759716'); 
INSERT INTO `wp_user_activity` VALUES ('2', '0', '1376759420');
# --------------------------------------------------------

