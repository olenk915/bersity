CREATE TABLE IF NOT EXISTS `wp_bp_user_blogs_blogmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blog_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bp_user_blogs_blogmeta`;
 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('1', '1', 'name', 'BandVersity'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('2', '1', 'description', 'Find out what&#039;s happening in universities now with the friends and bands you care about.'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('3', '1', 'last_activity', '2014-01-06 21:43:08'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('9', '3', 'last_activity', '2013-03-04 18:08:12'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('8', '3', 'description', 'Just another BandVersity Sites site'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('7', '3', 'name', 'Syracuse'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('15', '5', 'last_activity', '2013-06-23 20:43:17'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('14', '5', 'description', 'Just another BandVersity Sites site'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('13', '5', 'name', 'My sweet school.'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('16', '6', 'name', 'sandy own site'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('17', '6', 'description', 'Just another BandVersity Sites site'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('18', '6', 'last_activity', '2013-07-01 18:46:07'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('19', '7', 'name', 'Iris demo blog'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('20', '7', 'description', 'Just another BandVersity Sites site'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('21', '7', 'last_activity', '2013-07-01 18:53:09');
# --------------------------------------------------------

