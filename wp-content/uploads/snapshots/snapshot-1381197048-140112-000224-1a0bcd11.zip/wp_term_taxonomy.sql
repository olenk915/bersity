CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_term_taxonomy`;
 
INSERT INTO `wp_term_taxonomy` VALUES ('1', '1', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('2', '2', 'link_category', '', '0', '7'); 
INSERT INTO `wp_term_taxonomy` VALUES ('18', '18', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('19', '19', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('20', '20', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('21', '21', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('22', '22', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('23', '23', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('24', '24', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('41', '41', 'topic-tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('36', '36', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('25', '25', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('26', '26', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('27', '27', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('28', '28', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('29', '29', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('30', '30', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('31', '31', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('32', '32', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('33', '33', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('34', '34', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('35', '35', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('37', '37', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('38', '38', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('39', '39', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('40', '40', 'topic-tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('42', '42', 'topic-tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('43', '43', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('44', '44', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('45', '45', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('46', '46', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('47', '47', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('48', '48', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('49', '49', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('50', '50', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('51', '51', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('52', '52', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('55', '55', 'category', '', '47', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('54', '54', 'category', '', '47', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('56', '56', 'category', '', '55', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('57', '57', 'category', '', '55', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('58', '58', 'category', '', '55', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('59', '59', 'category', '', '54', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('60', '60', 'category', '', '54', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('61', '61', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('75', '75', 'category', '', '63', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('63', '63', 'category', '', '0', '6'); 
INSERT INTO `wp_term_taxonomy` VALUES ('64', '64', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('65', '65', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('66', '66', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('67', '67', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('68', '68', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('69', '69', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('70', '70', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('71', '71', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('72', '72', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('73', '73', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('74', '74', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('76', '76', 'category', '', '63', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('77', '77', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('78', '78', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('79', '79', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('80', '80', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('81', '81', 'post_tag', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('82', '82', 'post_tag', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('83', '83', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('84', '84', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('85', '85', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('86', '86', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('87', '87', 'post_tag', '', '0', '1');
# --------------------------------------------------------

