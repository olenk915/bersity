CREATE TABLE IF NOT EXISTS `wp_bp_notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `secondary_item_id` bigint(20) DEFAULT NULL,
  `component_name` varchar(75) NOT NULL,
  `component_action` varchar(75) NOT NULL,
  `date_notified` datetime NOT NULL,
  `is_new` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `secondary_item_id` (`secondary_item_id`),
  KEY `user_id` (`user_id`),
  KEY `is_new` (`is_new`),
  KEY `component_name` (`component_name`),
  KEY `component_action` (`component_action`),
  KEY `useritem` (`user_id`,`is_new`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bp_notifications`;
 
INSERT INTO `wp_bp_notifications` VALUES ('1', '176', '1', '0', 'friends', 'friendship_request', '2013-05-28 15:50:01', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('2', '180', '1', '0', 'friends', 'friendship_request', '2013-05-28 15:50:06', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('3', '75', '1', '0', 'friends', 'friendship_request', '2013-05-28 15:50:10', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('4', '203', '1', '0', 'friends', 'friendship_request', '2013-06-05 00:16:24', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('5', '115', '666', '223', 'activity', 'new_at_mention', '2013-06-28 14:50:00', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('7', '219', '1', '0', 'friends', 'friendship_accepted', '2013-06-30 04:18:53', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('20', '226', '229', '0', 'friends', 'friendship_request', '2013-10-02 03:44:51', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('9', '225', '223', '94', 'groups', 'new_membership_request', '2013-07-08 20:52:39', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('11', '225', '223', '0', 'friends', 'friendship_request', '2013-07-09 03:49:44', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('16', '222', '227', '0', 'friends', 'friendship_accepted', '2013-07-25 00:37:41', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('17', '222', '96', '0', 'groups', 'membership_request_accepted', '2013-07-25 00:38:29', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('21', '225', '229', '0', 'friends', 'friendship_request', '2013-10-02 03:44:51', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('60', '225', '229', '94', 'groups', 'new_membership_request', '2013-10-07 04:28:39', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('63', '225', '240', '94', 'groups', 'new_membership_request', '2013-10-10 04:49:57', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('58', '235', '229', '0', 'friends', 'friendship_request', '2013-10-07 04:23:35', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('55', '231', '229', '0', 'friends', 'friendship_accepted', '2013-10-07 04:21:55', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('59', '222', '229', '97', 'groups', 'new_membership_request', '2013-10-07 04:28:36', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('56', '234', '229', '0', 'friends', 'friendship_accepted', '2013-10-07 04:22:02', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('49', '232', '234', '0', 'friends', 'friendship_request', '2013-10-07 02:26:19', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('50', '228', '234', '0', 'friends', 'friendship_request', '2013-10-07 02:26:26', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('67', '229', '241', '0', 'friends', 'friendship_accepted', '2013-12-23 23:18:50', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('62', '232', '229', '0', 'friends', 'friendship_request', '2013-10-07 04:29:43', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('61', '233', '229', '0', 'friends', 'friendship_request', '2013-10-07 04:29:40', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('52', '225', '234', '0', 'friends', 'friendship_request', '2013-10-07 02:26:35', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('53', '226', '234', '0', 'friends', 'friendship_request', '2013-10-07 02:26:40', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('65', '237', '229', '0', 'friends', 'friendship_request', '2013-12-23 23:18:07', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('69', '229', '240', '0', 'friends', 'friendship_accepted', '2013-12-25 18:54:26', '1'); 
INSERT INTO `wp_bp_notifications` VALUES ('68', '236', '229', '0', 'friends', 'friendship_request', '2013-12-23 23:19:08', '1');
# --------------------------------------------------------

