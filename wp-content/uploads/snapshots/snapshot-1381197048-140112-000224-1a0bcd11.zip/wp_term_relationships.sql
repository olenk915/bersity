CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_term_relationships`;
 
INSERT INTO `wp_term_relationships` VALUES ('1', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('2', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('3', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('4', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('5', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('6', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('7', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('290', '71', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('270', '65', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('270', '64', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('271', '63', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('271', '66', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('212', '41', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('283', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('271', '75', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('290', '67', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('286', '61', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('287', '63', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('270', '63', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('290', '68', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('17', '18', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('265', '52', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('250', '42', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('290', '70', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('290', '69', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('295', '49', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('266', '52', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('290', '72', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('290', '73', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('290', '74', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('290', '76', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('287', '75', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('278', '43', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('295', '77', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('270', '76', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('290', '63', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('270', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('295', '78', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('298', '79', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('298', '63', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('298', '76', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('298', '80', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('298', '81', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('298', '82', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('298', '83', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('298', '84', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('298', '85', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('298', '86', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('302', '87', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('302', '63', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('302', '76', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('302', '81', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('302', '82', '0');
# --------------------------------------------------------

