CREATE TABLE IF NOT EXISTS `wp_bb_topics` (
  `topic_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `topic_title` varchar(100) NOT NULL DEFAULT '',
  `topic_slug` varchar(255) NOT NULL DEFAULT '',
  `topic_poster` bigint(20) NOT NULL DEFAULT '0',
  `topic_poster_name` varchar(40) NOT NULL DEFAULT 'Anonymous',
  `topic_last_poster` bigint(20) NOT NULL DEFAULT '0',
  `topic_last_poster_name` varchar(40) NOT NULL DEFAULT '',
  `topic_start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `topic_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `forum_id` int(10) NOT NULL DEFAULT '1',
  `topic_status` tinyint(1) NOT NULL DEFAULT '0',
  `topic_open` tinyint(1) NOT NULL DEFAULT '1',
  `topic_last_post_id` bigint(20) NOT NULL DEFAULT '1',
  `topic_sticky` tinyint(1) NOT NULL DEFAULT '0',
  `topic_posts` bigint(20) NOT NULL DEFAULT '0',
  `tag_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topic_id`),
  KEY `topic_slug` (`topic_slug`),
  KEY `forum_time` (`forum_id`,`topic_time`),
  KEY `user_start_time` (`topic_poster`,`topic_start_time`),
  KEY `stickies` (`topic_status`,`topic_sticky`,`topic_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bb_topics`;

# --------------------------------------------------------

