CREATE TABLE IF NOT EXISTS `wp_bb_forums` (
  `forum_id` int(10) NOT NULL AUTO_INCREMENT,
  `forum_name` varchar(150) NOT NULL DEFAULT '',
  `forum_slug` varchar(255) NOT NULL DEFAULT '',
  `forum_desc` text NOT NULL,
  `forum_parent` int(10) NOT NULL DEFAULT '0',
  `forum_order` int(10) NOT NULL DEFAULT '0',
  `topics` bigint(20) NOT NULL DEFAULT '0',
  `posts` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`forum_id`),
  KEY `forum_slug` (`forum_slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bb_forums`;

# --------------------------------------------------------

