CREATE TABLE IF NOT EXISTS `wp_bb_posts` (
  `post_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `forum_id` int(10) NOT NULL DEFAULT '1',
  `topic_id` bigint(20) NOT NULL DEFAULT '1',
  `poster_id` int(10) NOT NULL DEFAULT '0',
  `post_text` text NOT NULL,
  `post_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `poster_ip` varchar(15) NOT NULL DEFAULT '',
  `post_status` tinyint(1) NOT NULL DEFAULT '0',
  `post_position` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`post_id`),
  KEY `topic_time` (`topic_id`,`post_time`),
  KEY `poster_time` (`poster_id`,`post_time`),
  KEY `post_time` (`post_time`),
  FULLTEXT KEY `post_text` (`post_text`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bb_posts`;

# --------------------------------------------------------

