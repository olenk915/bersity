CREATE TABLE IF NOT EXISTS `wp_bp_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `creator_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `description` longtext NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'public',
  `enable_forum` tinyint(1) NOT NULL DEFAULT '1',
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `creator_id` (`creator_id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bp_groups`;
 
INSERT INTO `wp_bp_groups` VALUES ('94', '225', 'Syracuse students', 'syracuse-students', 'a group for students who go to SU!', 'private', '1', '2013-07-08 17:13:19'); 
INSERT INTO `wp_bp_groups` VALUES ('95', '226', 'Triathlon Club', 'triathlon-club', 'train and compete', 'public', '1', '2013-07-09 16:01:06'); 
INSERT INTO `wp_bp_groups` VALUES ('96', '227', 'Pace University Students', 'pace-university-students', 'Open to all students of Pace University in New York City', 'private', '1', '2013-07-09 18:43:34'); 
INSERT INTO `wp_bp_groups` VALUES ('97', '222', 'Let’s Get a Job!!!', 'lets-get-a-job', 'This is for friends who will network together in hopes of finding a entry level job or an internship. ', 'private', '1', '2013-07-23 17:59:28'); 
INSERT INTO `wp_bp_groups` VALUES ('102', '231', 'SUNY Oneonta Students', 'suny-oneonta-students', 'Great place for Oneonta students, who are new to BandVersity, to post about and discuss music they are interested in.  Also a great place to spread  the news of where and when our favorite Oneonta bands are performing.', 'public', '1', '2013-10-06 21:55:13'); 
INSERT INTO `wp_bp_groups` VALUES ('103', '228', 'Musicians Unite: SUNY College at Oneonta', 'mucians-unite-suny-college-at-oneonta', 'A good for students to share their music ', 'public', '1', '2013-10-06 23:19:21'); 
INSERT INTO `wp_bp_groups` VALUES ('104', '232', 'Singing Prodigy', 'singing-prodigy', 'If you think you can sing, join this group, and share your talent.', 'public', '0', '2013-10-07 02:15:29'); 
INSERT INTO `wp_bp_groups` VALUES ('105', '235', 'Bon Jovi', 'bon-jovi', 'This group is to talk about bon jovi and to state your favorite song', 'public', '1', '2013-10-07 02:16:05'); 
INSERT INTO `wp_bp_groups` VALUES ('106', '234', 'Rap Artist 2013', 'rap-artist-2013', 'For people who enjoy listening and making rap', 'public', '1', '2013-10-07 02:16:17'); 
INSERT INTO `wp_bp_groups` VALUES ('107', '233', 'Lynyrd Skynyrd', 'lynyrd-skynyrd', 'This group is about the great music Lynyrd Skynyrd played Live from Freedom Hall', 'public', '1', '2013-10-07 02:16:37');
# --------------------------------------------------------

