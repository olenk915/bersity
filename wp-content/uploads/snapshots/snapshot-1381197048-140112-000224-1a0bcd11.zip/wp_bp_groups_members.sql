CREATE TABLE IF NOT EXISTS `wp_bp_groups_members` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `inviter_id` bigint(20) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `is_mod` tinyint(1) NOT NULL DEFAULT '0',
  `user_title` varchar(100) NOT NULL,
  `date_modified` datetime NOT NULL,
  `comments` longtext NOT NULL,
  `is_confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `is_banned` tinyint(1) NOT NULL DEFAULT '0',
  `invite_sent` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `is_admin` (`is_admin`),
  KEY `is_mod` (`is_mod`),
  KEY `user_id` (`user_id`),
  KEY `inviter_id` (`inviter_id`),
  KEY `is_confirmed` (`is_confirmed`)
) ENGINE=MyISAM AUTO_INCREMENT=155 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bp_groups_members`;
 
INSERT INTO `wp_bp_groups_members` VALUES ('130', '104', '232', '0', '1', '0', 'Group Admin', '2013-10-07 02:15:29', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('131', '105', '235', '0', '1', '0', 'Group Admin', '2013-10-07 02:16:05', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('152', '104', '229', '0', '0', '0', '', '2013-10-07 04:28:57', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('151', '94', '229', '0', '0', '0', '', '2013-10-07 04:28:39', '', '0', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('150', '97', '229', '0', '0', '0', '', '2013-10-07 04:28:36', '', '0', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('149', '106', '231', '0', '0', '0', '', '2013-10-07 02:45:42', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('148', '104', '231', '0', '0', '0', '', '2013-10-07 02:45:28', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('147', '105', '231', '0', '0', '0', '', '2013-10-07 02:45:26', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('146', '105', '233', '0', '0', '0', '', '2013-10-07 02:23:54', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('145', '104', '233', '0', '0', '0', '', '2013-10-07 02:23:49', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('144', '106', '233', '0', '0', '0', '', '2013-10-07 02:23:47', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('143', '103', '235', '0', '0', '0', '', '2013-10-07 02:19:39', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('142', '107', '235', '0', '0', '0', '', '2013-10-07 02:19:24', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('141', '106', '235', '0', '0', '0', '', '2013-10-07 02:19:18', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('140', '104', '235', '0', '0', '0', '', '2013-10-07 02:19:12', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('139', '104', '234', '0', '0', '0', '', '2013-10-07 02:19:01', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('138', '106', '232', '0', '0', '0', '', '2013-10-07 02:18:38', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('137', '107', '232', '0', '0', '0', '', '2013-10-07 02:18:33', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('136', '105', '234', '0', '0', '0', '', '2013-10-07 02:18:20', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('135', '107', '234', '0', '0', '0', '', '2013-10-07 02:18:19', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('134', '105', '232', '0', '0', '0', '', '2013-10-07 02:18:17', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('133', '107', '233', '0', '1', '0', 'Group Admin', '2013-10-07 02:16:37', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('132', '106', '234', '0', '1', '0', 'Group Admin', '2013-10-07 02:16:17', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('129', '103', '233', '0', '0', '0', '', '2013-10-07 02:13:40', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('128', '102', '232', '0', '0', '0', '', '2013-10-07 02:13:29', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('106', '94', '225', '0', '1', '0', 'Group Admin', '2013-07-08 17:13:19', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('107', '94', '223', '0', '0', '0', '', '2013-07-08 20:52:39', '', '0', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('109', '95', '226', '0', '1', '0', 'Group Admin', '2013-07-09 16:01:07', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('154', '94', '240', '0', '0', '0', '', '2013-10-10 04:49:57', 'I am a Music Industry major here and am definitely interested in what this site can bring.  ', '0', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('111', '96', '227', '0', '1', '0', 'Group Admin', '2013-07-09 18:43:34', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('112', '96', '222', '0', '0', '0', '', '2013-07-25 00:38:28', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('113', '97', '222', '0', '1', '0', 'Group Admin', '2013-07-23 17:59:28', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('114', '96', '1', '0', '0', '0', '', '2013-07-29 22:47:42', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('119', '102', '231', '0', '1', '0', 'Group Admin', '2013-10-06 21:55:13', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('120', '102', '228', '0', '0', '0', '', '2013-10-06 23:17:25', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('121', '103', '228', '0', '1', '0', 'Group Admin', '2013-10-06 23:19:21', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('123', '103', '231', '0', '0', '0', '', '2013-10-07 01:03:36', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('124', '102', '235', '0', '0', '0', '', '2013-10-07 02:13:09', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('126', '102', '233', '0', '0', '0', '', '2013-10-07 02:13:22', '', '1', '0', '0'); 
INSERT INTO `wp_bp_groups_members` VALUES ('127', '103', '232', '0', '0', '0', '', '2013-10-07 02:13:25', '', '1', '0', '0');
# --------------------------------------------------------

