CREATE TABLE IF NOT EXISTS `wp_bp_friends` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `initiator_user_id` bigint(20) NOT NULL,
  `friend_user_id` bigint(20) NOT NULL,
  `is_confirmed` tinyint(1) DEFAULT '0',
  `is_limited` tinyint(1) DEFAULT '0',
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `initiator_user_id` (`initiator_user_id`),
  KEY `friend_user_id` (`friend_user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bp_friends`;
 
INSERT INTO `wp_bp_friends` VALUES ('7', '223', '225', '0', '0', '2013-07-09 03:49:44'); 
INSERT INTO `wp_bp_friends` VALUES ('5', '219', '1', '1', '0', '2013-06-30 04:18:53'); 
INSERT INTO `wp_bp_friends` VALUES ('6', '223', '1', '0', '0', '2013-07-09 03:48:22'); 
INSERT INTO `wp_bp_friends` VALUES ('8', '222', '227', '1', '0', '2013-07-25 00:37:41'); 
INSERT INTO `wp_bp_friends` VALUES ('9', '229', '226', '0', '0', '2013-10-02 03:44:51'); 
INSERT INTO `wp_bp_friends` VALUES ('10', '229', '225', '0', '0', '2013-10-02 03:44:51'); 
INSERT INTO `wp_bp_friends` VALUES ('11', '228', '231', '1', '0', '2013-10-06 23:26:42'); 
INSERT INTO `wp_bp_friends` VALUES ('12', '228', '229', '1', '0', '2013-10-07 04:22:03'); 
INSERT INTO `wp_bp_friends` VALUES ('13', '231', '229', '1', '0', '2013-10-07 04:21:54'); 
INSERT INTO `wp_bp_friends` VALUES ('14', '228', '235', '1', '0', '2013-10-07 02:24:24'); 
INSERT INTO `wp_bp_friends` VALUES ('15', '228', '233', '1', '0', '2013-10-07 02:25:17'); 
INSERT INTO `wp_bp_friends` VALUES ('16', '228', '232', '1', '0', '2013-10-07 02:25:38'); 
INSERT INTO `wp_bp_friends` VALUES ('17', '232', '235', '1', '0', '2013-10-07 02:24:25'); 
INSERT INTO `wp_bp_friends` VALUES ('18', '233', '235', '1', '0', '2013-10-07 02:24:20'); 
INSERT INTO `wp_bp_friends` VALUES ('19', '233', '232', '1', '0', '2013-10-07 02:25:31'); 
INSERT INTO `wp_bp_friends` VALUES ('20', '233', '234', '1', '0', '2013-10-07 02:25:16'); 
INSERT INTO `wp_bp_friends` VALUES ('21', '231', '233', '1', '0', '2013-10-07 02:25:14'); 
INSERT INTO `wp_bp_friends` VALUES ('22', '231', '235', '1', '0', '2013-10-07 02:24:21'); 
INSERT INTO `wp_bp_friends` VALUES ('23', '231', '232', '1', '0', '2013-10-07 02:25:36'); 
INSERT INTO `wp_bp_friends` VALUES ('24', '231', '234', '1', '0', '2013-10-07 02:25:17'); 
INSERT INTO `wp_bp_friends` VALUES ('25', '234', '232', '0', '0', '2013-10-07 02:26:19'); 
INSERT INTO `wp_bp_friends` VALUES ('26', '234', '228', '0', '0', '2013-10-07 02:26:26'); 
INSERT INTO `wp_bp_friends` VALUES ('27', '234', '229', '1', '0', '2013-10-07 04:22:02'); 
INSERT INTO `wp_bp_friends` VALUES ('28', '234', '225', '0', '0', '2013-10-07 02:26:35'); 
INSERT INTO `wp_bp_friends` VALUES ('29', '234', '226', '0', '0', '2013-10-07 02:26:40'); 
INSERT INTO `wp_bp_friends` VALUES ('30', '229', '235', '0', '0', '2013-10-07 04:23:35'); 
INSERT INTO `wp_bp_friends` VALUES ('31', '229', '233', '0', '0', '2013-10-07 04:29:39'); 
INSERT INTO `wp_bp_friends` VALUES ('32', '229', '232', '0', '0', '2013-10-07 04:29:43'); 
INSERT INTO `wp_bp_friends` VALUES ('33', '229', '241', '1', '0', '2013-12-23 23:18:50'); 
INSERT INTO `wp_bp_friends` VALUES ('34', '229', '237', '0', '0', '2013-12-23 23:18:07'); 
INSERT INTO `wp_bp_friends` VALUES ('35', '229', '240', '1', '0', '2013-12-25 18:54:26'); 
INSERT INTO `wp_bp_friends` VALUES ('36', '229', '236', '0', '0', '2013-12-23 23:19:08');
# --------------------------------------------------------

