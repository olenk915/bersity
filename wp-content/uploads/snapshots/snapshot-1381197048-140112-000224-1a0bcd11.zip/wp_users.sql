CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `user_login` (`user_login`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_registered` (`user_registered`)
) ENGINE=MyISAM AUTO_INCREMENT=249 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_users`;
 
INSERT INTO `wp_users` VALUES ('1', 'BVersity', '$P$B.xhnpodkBJEzyvJWkRwChFgDPFctZ.', 'bversity', 'iris@entmarketing.com', '', '2012-10-26 18:52:26', '', '0', 'BVersity', '0', '0'); 
INSERT INTO `wp_users` VALUES ('2', 'bruno', '$P$BbES1u22crxN9XxOORHYZQWXKTBCWW.', 'bruno', 'granbr@gmail.com', '', '2012-11-02 19:31:57', '', '0', 'bruno', '0', '0'); 
INSERT INTO `wp_users` VALUES ('4', 'nsswdo4141', '$P$BYzKi3vjiQZfg0lAh8gN1/r7S3EQi71', 'nsswdo4141', 'newday80002@gmail.com', '', '2013-03-07 02:33:10', '', '0', 'BakerMalcolm', '0', '0'); 
INSERT INTO `wp_users` VALUES ('224', 'sandy111', '$P$BtPxRiBJ1UhLceGecHCwh/.26fMbJo1', 'sandy111', 'salehul@anblik.com', '', '2013-07-01 18:46:06', '', '0', 'sandy111', '0', '0'); 
INSERT INTO `wp_users` VALUES ('225', 'rahart616', '$P$BGZ29WzwwadyV7djJQnCxJ18Q04qna1', 'rahart616', 'Rehart@syr.edu', '', '2013-07-05 18:59:47', '', '0', 'Rebecca Hart', '0', '0'); 
INSERT INTO `wp_users` VALUES ('226', 'christy77', '$P$B0bxh99V1QaO265aIdp63p6q9VrdkQ/', 'christy77', 'cambrosi@usc.edu', '', '2013-07-09 15:45:16', '', '0', 'Christy Ambrosini', '0', '0'); 
INSERT INTO `wp_users` VALUES ('227', 'neysas', '$P$BI50hmvIFj6a2.Erxk5pNE7lsuT4BA1', 'neysas', 'ns24019p@pace.edu', '', '2013-07-09 18:30:22', '', '0', 'Neysa Smith', '0', '0'); 
INSERT INTO `wp_users` VALUES ('228', 'danaglatzer', '$P$BHiEUZdTTi/YXr0qMWugkYkZy.5MbC0', 'danaglatzer', 'glatda08@suny.oneonta.edu', '', '2013-09-21 19:46:40', '', '0', 'Dana Glatzer', '0', '0'); 
INSERT INTO `wp_users` VALUES ('229', 'eajackso', '$P$Bxd1s8GJp9rcJg2fIFfHQMMaRW8f2y0', 'eajackso', 'eajackso@syr.edu', '', '2013-09-22 23:12:57', '', '0', 'Erica Jackson', '0', '0'); 
INSERT INTO `wp_users` VALUES ('230', 'orentaub', '$P$BzDVwgPewOMb71baXsa9mI/QAnxzNv/', 'orentaub', 'oren@orendesigns.com', '', '2013-10-01 19:12:51', '', '0', 'orentaub', '0', '0'); 
INSERT INTO `wp_users` VALUES ('231', 'maddie1', '$P$BWI5qaVrGczlt2VVDiOcihe44704GL1', 'maddie1', 'gencms21@suny.oneonta.edu', '', '2013-10-06 21:47:17', '', '0', 'Maddie Genco', '0', '0'); 
INSERT INTO `wp_users` VALUES ('232', 'kris755', '$P$B4HupES1OwpV1wrZ5msmmgrnGjx.p/1', 'kris755', 'regakr43@suny.oneonta.edu', '', '2013-10-07 02:00:50', '', '0', 'Kristofer Regan', '0', '0'); 
INSERT INTO `wp_users` VALUES ('233', 'hunterham007', '$P$BVhScVLRlZufxSzXDugY/sSROcQN/q0', 'hunterham007', 'hamihj47@suny.oneonta.edu', '', '2013-10-07 02:00:53', '', '0', 'Hunter Hamilton', '0', '0'); 
INSERT INTO `wp_users` VALUES ('234', 'moderc78', '$P$BeBMjL4y1BPFu2/9W0ZTvL.KjfeDyC1', 'moderc78', 'MODERC78@suny.oneonta.edu', '', '2013-10-07 02:01:50', '', '0', 'Roberto Modesto', '0', '0'); 
INSERT INTO `wp_users` VALUES ('235', 'rosets02', '$P$BfFu0qXsGqwvOmPdY2.0O.bhzFEOJr.', 'rosets02', 'rosets02@suny.oneonta.edu', '', '2013-10-07 02:01:56', '', '0', 'Tyler Rosenberg', '0', '0'); 
INSERT INTO `wp_users` VALUES ('236', 'joshbythebay', '$P$BrJ/n2SsJog7r2rqyEOH7kCRX0itr/0', 'joshbythebay', 'jljackso@syr.edu', '', '2013-10-09 15:59:30', '', '0', 'Josh Jackson', '0', '0'); 
INSERT INTO `wp_users` VALUES ('237', 'michael2929', '$P$BPAXUjHZBEnleuGiaAjXOkNhkhVR/N1', 'michael2929', 'n00789350@students.ncc.edu', '', '2013-10-09 21:08:16', '', '0', 'michael vassallo', '0', '0'); 
INSERT INTO `wp_users` VALUES ('238', 'ariellafsuchow', '$P$BuorYAFRRGvTVow0fHaWkzFIb4d8dj1', 'ariellafsuchow', 'ariella_katz@emerson.edu', '', '2013-10-09 22:42:43', '', '0', 'Ariella Suchow', '0', '0'); 
INSERT INTO `wp_users` VALUES ('239', 'suchow', '$P$B4soXTHTpH680vsi2PasC9CG7nHcQd0', 'suchow', 'suchow@fas.harvard.edu', '', '2013-10-09 22:52:56', '', '0', 'Jordan Suchow', '0', '0'); 
INSERT INTO `wp_users` VALUES ('240', 'dylanrocke', '$P$BtGwKNot7oJbczKC4J1iFBAG3K./Ps.', 'dylanrocke', 'dmrocke@syr.edu', '', '2013-10-10 04:48:27', '', '0', 'Dylan Rocke', '0', '0'); 
INSERT INTO `wp_users` VALUES ('241', 'sebastianzar', '$P$BMfks10IAGrvJD1HMjSDyrOyMyP7GC/', 'sebastianzar', 'szar@syr.edu', '', '2013-10-15 14:29:10', '', '0', 'Sebastian Zar', '0', '0'); 
INSERT INTO `wp_users` VALUES ('242', 'shutupjade', '$P$BWFpzgLzmL9U7jSg7HWUYittZpNQPp.', 'shutupjade', 'jpilgrom@c.ringling.edu', '', '2013-10-22 02:55:33', '', '0', 'Jade Pilgrom', '0', '0'); 
INSERT INTO `wp_users` VALUES ('243', 'jmyrthil', '$P$BROhkejWenXIX4qzqlPZAjiJNvsGXK/', 'jmyrthil', 'jm21949n@pace.edu', '', '2013-12-04 18:28:53', '', '0', 'sports', '0', '0'); 
INSERT INTO `wp_users` VALUES ('244', 'rahhhkim', '$P$BuwpvNTNGpS51rwiA1yR/WZ2nd8LJ9/', 'rahhhkim', 'kv25404n@pace.edu', '', '2013-12-04 21:01:09', '', '0', 'Kimberley Valderas', '0', '0'); 
INSERT INTO `wp_users` VALUES ('245', 'waldomontes', '$P$BYygZJM7iE/yRufZoug6dsFqIwHDfS.', 'waldomontes', 'km89717n@pace.edu', '', '2013-12-16 09:29:29', '', '0', 'Kevin Montes', '0', '0'); 
INSERT INTO `wp_users` VALUES ('246', 'hilsenrod2', '$P$BQ/gvVP1Lf4BR79I.N2lmCxk2hc4yl/', 'hilsenrod2', 'Hhilsenrod@utexas.edu', '', '2013-12-24 00:06:47', '', '0', 'Heather Hilsenrod', '0', '0'); 
INSERT INTO `wp_users` VALUES ('247', 'jacobprussman', '$P$B4Nwv0.WQDWQ1eE.ePow.dMVetQSSw/', 'jacobprussman', 'jap7272@uncw.edu', '', '2013-12-24 17:23:37', '', '0', 'Jacob Prussman', '0', '0'); 
INSERT INTO `wp_users` VALUES ('248', 'rdely', '$P$B1BFIqMuvfUYWPaMlUc.Ioe5yhOpx..', 'rdely', 'rdely@syr.edu', '', '2014-01-09 05:16:59', '', '0', 'Rachel Dely', '0', '0'); 
INSERT INTO `wp_users` VALUES ('163', 'robesau7290', '$P$Bn2HOIxI/Uiv3XQEi63iA.NoscG3dO/', 'robesau7290', 'richardpammenter3836@mailnesia.com', '', '2013-05-19 17:44:09', '', '0', 'Connor Gagnon', '0', '0'); 
INSERT INTO `wp_users` VALUES ('169', 'marcboyd8199', '$P$BQqhqYNtfEYl8mEcn7EXbllLW4JDh9.', 'marcboyd8199', 'coltongodfrey9427@mailnesia.com', '', '2013-05-20 06:39:43', '', '0', 'Richie Reed', '0', '0'); 
INSERT INTO `wp_users` VALUES ('187', 'samelonki', '$P$BpBd86dindQI65pVt64l0SBKqAqQtQ0', 'samelonki', '9bdprs@autisticsociety.info', '', '2013-05-24 13:31:09', '', '0', 'samelonkiRA', '0', '0'); 
INSERT INTO `wp_users` VALUES ('188', 'beagmamoima', '$P$BLRuvTc82NbSYjbqaEfYBWcQfh6yIM/', 'beagmamoima', 'accuttdum@hotmail.com', '', '2013-05-24 18:17:57', '', '0', 'beagmamoimaSV', '0', '0'); 
INSERT INTO `wp_users` VALUES ('197', 'lorenzocl', '$P$B6wFIh6FDNYEAVSjCCR5b6vVVsv2fK.', 'lorenzocl', 'vcvcvcvsddfdf@hotmail.com', '', '2013-06-03 18:09:10', '', '0', 'Lorenzo Clanton', '0', '0'); 
INSERT INTO `wp_users` VALUES ('198', 'aidanqys', '$P$BtV/xLlr/jXbM9rUlAICvfJ.TsKrXS/', 'aidanqys', 'loviebmuw@outlook.com', '', '2013-06-04 09:15:44', '', '0', 'Aidan Rigby', '0', '0'); 
INSERT INTO `wp_users` VALUES ('200', 'lucasrand', '$P$BwoWfdY13WSR49QvqdPQHF9XVMUTvm/', 'lucasrand', 'dsf34343ddfa@pozyczkiprywatne24.net', '', '2013-06-04 15:47:38', '', '0', 'Lucas Randall', '0', '0'); 
INSERT INTO `wp_users` VALUES ('204', 'agnesdozi', '$P$BVc.xoNKDkWM95oO53mN4Nv.pK12El0', 'agnesdozi', 'agnes_dozier@mailnesia.com', '', '2013-06-05 00:30:05', '', '0', 'Agnes Dozier', '0', '0'); 
INSERT INTO `wp_users` VALUES ('210', 'utekwlt', '$P$BoGXzH9i3.UE9/oGNvofwOSH57YUDe0', 'utekwlt', 'redusrwa@hotmail.com', '', '2013-06-06 01:53:05', '', '0', 'Ute Camacho', '0', '0'); 
INSERT INTO `wp_users` VALUES ('211', 'mohamedah', '$P$BmSqE08AK4lryRjQSqkaoovD/RwI0P.', 'mohamedah', 'brunkhkh@hotmail.com', '', '2013-06-06 06:06:54', '', '0', 'Mohamed Ahern', '0', '0'); 
INSERT INTO `wp_users` VALUES ('218', 'larrychiagouris', '$P$BRiITfPKr9nPK8tGZKwwwxk40BcQog.', 'larrychiagouris', 'lchiagouris@pace.edu', '', '2013-06-19 14:17:10', '', '0', 'what is this', '0', '0'); 
INSERT INTO `wp_users` VALUES ('219', 'sandy123', '$P$BgYZX9MgcOPqllrmZeA83aJT55KlmV1', 'sandy123', 'salehul.h@gmail.com', '', '2013-06-23 20:43:15', '', '0', 'Sandy Developer', '0', '0'); 
INSERT INTO `wp_users` VALUES ('220', 'risi', '$P$BgLDlODYCkdHYFGyG6ddUkPgMA8LAh0', 'risi', 'mohri@stjohns.edu', '', '2013-06-26 01:59:54', '', '0', 'Risi Mohr', '0', '0'); 
INSERT INTO `wp_users` VALUES ('222', 'vianojon', '$P$BcxNnQXpox3HTvzkTxn89HvXD6.Gm61', 'vianojon', 'jv12112n@pace.edu', '', '2013-06-27 23:39:22', '', '0', 'Jonathan Viano', '0', '0'); 
INSERT INTO `wp_users` VALUES ('223', 'arejay', '$P$B7lQGZHZXkOZIeudGG0UoNLKPEXw6V/', 'arejay', 'js53536n@pace.edu', '', '2013-06-28 14:34:50', '', '0', 'Arejay Silver', '0', '0');
# --------------------------------------------------------

